"use client";
import React, { useState } from "react";
import { FileUpload } from "@/components/ui/file-upload";
import Image from "next/image";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileUploadDemoProps {
  onFileUpload: (files: File[]) => void;
}

export function FileUploadDemo({ onFileUpload }: FileUploadDemoProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = async (files: File[]) => {
    if (!files.length) return;

    try {
      setIsProcessing(true);
      setError(null);
      setProcessedImage(null);
      setFiles(files);
      onFileUpload(files);

      // Display original image preview
      const originalUrl = URL.createObjectURL(files[0]);
      setOriginalImage(originalUrl);

      // Prepare form data
      const formData = new FormData();
      formData.append("file", files[0]);

      // Send to backend
      const response = await fetch("/api/process-image", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to process image");
      }

      const data = await response.json();

      // The backend returns a relative URL, make it absolute
      const processedImageUrl = `${
        process.env.NEXT_PUBLIC_BACKEND_URL || "http://127.0.0.1:8000"
      }${data.image_url}`;
      setProcessedImage(processedImageUrl);
    } catch (err) {
      console.error("Error uploading image:", err);
      let errorMessage = "Failed to process image";

      if (err instanceof Error) {
        if (err.message.includes("Cannot connect to the backend server")) {
          errorMessage =
            "Cannot connect to the image processing server. Please make sure it's running and try again.";
        } else if (err.message.includes("Authentication failed")) {
          errorMessage =
            "Authentication failed. Please check your Hugging Face token has the correct permissions.";
        } else if (
          err.message.includes("503") ||
          err.message.includes("Service Unavailable")
        ) {
          errorMessage =
            "The image processing service is currently unavailable. Please try again in a few minutes.";
        } else if (
          err.message.includes("All available models are currently unavailable")
        ) {
          errorMessage =
            "All image processing models are currently busy. Please try again in a few minutes.";
        } else {
          errorMessage = err.message;
        }
      }

      setError(errorMessage);
      setProcessedImage(null);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8">
      <div
        className={cn(
          "min-h-96 border border-dashed bg-white dark:bg-black border-neutral-200 dark:border-neutral-800 rounded-lg relative",
          isProcessing && "border-purple-500"
        )}
      >
        <FileUpload onChange={handleFileUpload} disabled={isProcessing} />
        {isProcessing && (
          <div className="absolute inset-0 bg-black/5 backdrop-blur-sm flex items-center justify-center">
            <div className="flex flex-col items-center space-y-4 bg-white dark:bg-black p-6 rounded-lg shadow-lg">
              <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Converting to Ghibli style...
              </p>
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="bg-red-50 dark:bg-red-950/50 text-red-500 dark:text-red-400 p-4 rounded-lg border border-red-200 dark:border-red-900">
          {error}
        </div>
      )}

      {(originalImage || processedImage) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {originalImage && (
            <div className="space-y-2">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Original Image
              </h3>
              <div className="relative aspect-square w-full bg-neutral-100 dark:bg-neutral-900 rounded-lg overflow-hidden">
                <Image
                  src={originalImage}
                  alt="Original"
                  fill
                  className="object-contain"
                  unoptimized
                />
              </div>
            </div>
          )}

          {processedImage && (
            <div className="space-y-2">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Ghibli Style
              </h3>
              <div className="relative aspect-square w-full bg-neutral-100 dark:bg-neutral-900 rounded-lg overflow-hidden">
                <Image
                  src={processedImage}
                  alt="Processed"
                  fill
                  className="object-contain"
                  unoptimized
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
