import { PutObjectCommandOutput, S3 } from "@aws-sdk/client-s3";

export async function uploadToS3(
  file: File | Blob,
  fileName?: string
): Promise<{ file_key: string; file_name: string }> {
  try {
    const s3 = new S3({
      region: "eu-north-1",
      credentials: {
        accessKeyId: process.env.NEXT_PUBLIC_S3_ACCESS_KEY_ID!,
        secretAccessKey: process.env.NEXT_PUBLIC_S3_SECRET_ACCESS_KEY!,
      },
    });

    const file_key =
      "uploads/" +
      Date.now().toString() +
      (fileName || "image.png").replace(" ", "-");

    // Convert File/Blob to Buffer
    const buffer = Buffer.from(await file.arrayBuffer());

    const params = {
      Bucket: process.env.NEXT_PUBLIC_S3_BUCKET_NAME!,
      Key: file_key,
      Body: buffer,
      ContentDisposition: "inline",
      ContentType: "image/png",
    };

    await s3.putObject(params);
    console.log("Successfully uploaded file to S3:", file_key);

    return {
      file_key,
      file_name: fileName || "image.png",
    };
  } catch (error) {
    console.error("Error in uploadToS3:", error);
    throw error;
  }
}

export function getS3Url(file_key: string) {
  const url = `https://${process.env.NEXT_PUBLIC_S3_BUCKET_NAME}.s3.eu-north-1.amazonaws.com/${file_key}`;
  return url;
}
