import {
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const userSystemEnum = pgEnum("user_system_enum", ["system", "user"]);

export const chats = pgTable("chats", {
  id: serial("id").primaryKey(),
  imageName: text("image_name").notNull(),
  imageUrl: text("image_url").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  userId: varchar("user_id", { length: 256 }).notNull(),
  fileKey: text("file_key").notNull(),
});

export type DrizzleChat = typeof chats.$inferSelect;

// export const messages = pgTable("messages", {
//   id: serial("id").primaryKey(),
//   chatId: integer("chat_id")
//     .references(() => chats.id)
//     .notNull(),
//   content: text("content").notNull(),
//   createdAt: timestamp("created_at").notNull().defaultNow(),
//   role: userSystemEnum("role").notNull(),
// });

export const userSubscriptions = pgTable("user_subscriptions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 256 }).notNull().unique(),
  stripeCustomerId: varchar("stripe_customer_id", { length: 256 })
    .notNull()
    .unique(),
  stripeSubscriptionId: varchar("stripe_subscription_id", {
    length: 256,
  }).unique(),
  stripePriceId: varchar("stripe_price_id", { length: 256 }),
  stripeCurrentPeriodEnd: timestamp("stripe_current_period_ended_at"),
});

export const images = pgTable("images", {
  id: serial("id").primaryKey(),
  originalImageUrl: text("original_image_url").notNull(),
  processedImageUrl: text("processed_image_url").notNull(),
  originalFileKey: text("original_file_key").notNull(),
  processedFileKey: text("processed_file_key").notNull(),
  userId: varchar("user_id", { length: 256 }).notNull(),
  status: varchar("status", { length: 50 }).notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type Image = typeof images.$inferSelect;
export type NewImage = typeof images.$inferInsert;

// Drizzle-orm
// drizzle-kit
