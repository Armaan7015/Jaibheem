"use client";
import { FileUploadDemo } from "@/components/FileUpload";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import Image from "next/image";

function Generate() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = async (files: File[]) => {
    if (files.length === 0) return;

    setIsProcessing(true);
    setError(null);
    setResultImage(null);

    try {
      const formData = new FormData();
      formData.append("file", files[0]);
      formData.append("userId", "test-user-123");

      const response = await fetch("/api/process-image", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to process image");
      }

      setResultImage(data.imageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="p-6 hover:shadow-lg transition-shadow">
          <FileUploadDemo onFileUpload={handleFileUpload} />
        </Card>
        <Card className="p-6 hover:shadow-lg transition-shadow">
          {isProcessing ? (
            <div className="flex flex-col items-center justify-center h-full">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 dark:border-white"></div>
              <p className="mt-4 text-center">Processing your image...</p>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center h-full">
              <p className="text-red-500 text-center">{error}</p>
            </div>
          ) : resultImage ? (
            <div className="flex flex-col items-center justify-center h-full">
              <div className="relative w-full aspect-square mb-4">
                <Image
                  src={resultImage}
                  alt="Ghibli-style result"
                  fill
                  className="object-contain rounded-lg"
                />
              </div>
              <Button
                onClick={() => window.open(resultImage, "_blank")}
                variant="outline"
              >
                Download Result
              </Button>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full">
              <p className="text-center text-gray-500">
                Upload an image to transform it into Ghibli style
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

export default Generate;
