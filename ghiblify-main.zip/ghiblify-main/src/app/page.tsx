"use client";
import React from "react";
import { Wind, Sparkles, Image, Wand2 } from "lucide-react";
import { useAuth } from "@clerk/nextjs";
import Link from "next/link";

function App() {
  const { isSignedIn } = useAuth();
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-100 to-purple-100 relative overflow-hidden">
      {/* Floating elements animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[
          { left: "10%", top: "20%", delay: "0s" },
          { left: "20%", top: "40%", delay: "1s" },
          { left: "30%", top: "60%", delay: "2s" },
          { left: "40%", top: "80%", delay: "3s" },
          { left: "50%", top: "30%", delay: "4s" },
          { left: "60%", top: "50%", delay: "0.5s" },
          { left: "70%", top: "70%", delay: "1.5s" },
          { left: "80%", top: "90%", delay: "2.5s" },
          { left: "90%", top: "10%", delay: "3.5s" },
          { left: "95%", top: "25%", delay: "4.5s" },
          { left: "5%", top: "35%", delay: "0.2s" },
          { left: "15%", top: "55%", delay: "1.2s" },
          { left: "25%", top: "75%", delay: "2.2s" },
          { left: "35%", top: "85%", delay: "3.2s" },
          { left: "45%", top: "15%", delay: "4.2s" },
          { left: "55%", top: "45%", delay: "0.8s" },
          { left: "65%", top: "65%", delay: "1.8s" },
          { left: "75%", top: "95%", delay: "2.8s" },
          { left: "85%", top: "5%", delay: "3.8s" },
          { left: "92%", top: "42%", delay: "4.8s" },
        ].map((pos, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: pos.left,
              top: pos.top,
              animationDelay: pos.delay,
              opacity: 0.3,
            }}
          >
            {i % 2 === 0 ? (
              <Wind className="text-purple-300" size={24} />
            ) : (
              <Sparkles className="text-blue-300" size={20} />
            )}
          </div>
        ))}
      </div>

      {/* Main content */}
      <div className="container mx-auto px-4 py-16 relative z-10">
        <nav className="flex justify-between items-center mb-16">
          <div className="flex items-center space-x-2">
            <Wand2 className="h-8 w-8 text-purple-600" />
            <span className="text-2xl font-semibold text-purple-600">
              Ghiblify
            </span>
          </div>
          <div className="space-x-8">
            <button className="text-gray-600 hover:text-purple-600 transition-colors">
              About
            </button>
            <button className="text-gray-600 hover:text-purple-600 transition-colors">
              Gallery
            </button>
            <Link
              href={isSignedIn ? "/dashboard" : "/auth/sign-up"}
              className="mb-10"
            >
              <button className="bg-purple-600 text-white px-6 py-2 rounded-full hover:bg-purple-700 transition-colors cursor-pointer">
                Get Started
              </button>
            </Link>
          </div>
        </nav>

        <main className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="lg:w-1/2 space-y-8">
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-800 leading-tight animate-fade-in">
              Transform Your Images into
              <span className="text-purple-600"> Ghibli Magic</span>
            </h1>
            <p className="text-xl text-gray-600 animate-fade-in-delay">
              Experience the enchanting world of Studio Ghibli through our
              AI-powered image generator. Convert your photos into breathtaking
              anime artworks inspired by the legendary studio.
            </p>
            <div className="flex space-x-4 animate-fade-in-delay-2">
              <Link
                href={isSignedIn ? "/dashboard" : "/auth/sign-up"}
                className="mb-10"
              >
                <button className="bg-purple-600 text-white px-8 py-3 rounded-full hover:bg-purple-700 transition-colors flex items-center space-x-2">
                  <Wand2 className="h-5 w-5" />
                  <span>Try Now</span>
                </button>
              </Link>
            </div>
          </div>

          <div className="lg:w-1/2 relative animate-float-slow">
            <div className="relative rounded-lg overflow-hidden shadow-2xl transform hover:scale-105 transition-transform duration-500">
              <img
                src="https://images.unsplash.com/photo-1475070929565-c985b496cb9f"
                alt="Mystical Forest"
                className="w-full object-cover rounded-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent">
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="flex items-center space-x-2 mb-2">
                    <Image className="h-5 w-5" />
                    <span>Original → Ghibli Style</span>
                  </div>
                  <div className="h-2 bg-white/30 rounded-full overflow-hidden">
                    <div className="w-2/3 h-full bg-purple-500 rounded-full animate-pulse"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>

        <section className="mt-24 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-12">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Image className="h-8 w-8 text-purple-600" />,
                title: "Upload Your Image",
                description: "Start with any photo you'd like to transform",
              },
              {
                icon: <Wand2 className="h-8 w-8 text-purple-600" />,
                title: "AI Magic",
                description: "Our AI applies the iconic Ghibli style",
              },
              {
                icon: <Sparkles className="h-8 w-8 text-purple-600" />,
                title: "Get Your Art",
                description: "Download your transformed masterpiece",
              },
            ].map((step, i) => (
              <div
                key={i}
                className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="flex justify-center mb-4">{step.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export default App;
