import { NextRequest, NextResponse } from "next/server";
import { uploadToS3, getS3Url } from "@/lib/s3";
import { db } from "@/lib/db";
import { images } from "@/lib/db/schema";
import OpenAI from "openai";
import sharp from "sharp";
import { eq } from "drizzle-orm";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export const config = {
  api: {
    bodyParser: false,
  },
};

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;
    const userId = formData.get("userId") as string;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    if (!userId) {
      return NextResponse.json(
        { error: "No user ID provided" },
        { status: 400 }
      );
    }

    // Process and upload original image
    const buffer = await file.arrayBuffer();
    const processedBuffer = await sharp(Buffer.from(buffer))
      .resize(1024, 1024, { fit: "inside" })
      .toFormat("png")
      .toBuffer();

    const { file_key: originalFileKey } = await uploadToS3(
      new Blob([processedBuffer], { type: "image/png" }),
      file.name
    );
    const originalImageUrl = getS3Url(originalFileKey);

    // Create database entry
    const [imageRecord] = await db
      .insert(images)
      .values({
        originalImageUrl,
        processedImageUrl: "", // Will be updated after processing
        originalFileKey,
        processedFileKey: "", // Will be updated after processing
        userId,
        status: "processing",
      })
      .returning();

    // First, analyze the image with GPT-4 Vision
    const visionResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this image and describe its key elements, composition, lighting, and subjects in detail. Focus on aspects that would be important for recreating it in Studio Ghibli style.",
            },
            { type: "image_url", image_url: { url: originalImageUrl } },
          ],
        },
      ],
      max_tokens: 500,
    });

    const imageAnalysis = visionResponse.choices[0].message.content;

    // Generate Ghibli-style image using DALL-E 3
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: `Create a Studio Ghibli style version of this scene: ${imageAnalysis}. 
      The image should maintain the exact same composition and subjects, but render them in the distinctive Studio Ghibli art style with these specific characteristics:
      - Soft, warm color palette with gentle gradients
      - Clean, precise linework typical of Ghibli animation
      - Subtle texturing and detailed shading
      - Maintain the exact same facial expressions and emotions
      - Keep all clothing details and patterns but render them in Ghibli's style
      - Preserve the lighting and atmosphere of the original scene
      The final result should look like a frame from a Studio Ghibli film while being instantly recognizable as the same scene.`,
      size: "1024x1024",
      quality: "hd",
      style: "vivid",
    });

    const processedImageUrl = response.data[0].url;
    if (!processedImageUrl) {
      throw new Error("No processed image URL received from DALL-E");
    }

    const processedImageResponse = await fetch(processedImageUrl);
    const processedImageBuffer = await processedImageResponse.arrayBuffer();

    const { file_key: processedFileKey } = await uploadToS3(
      new Blob([processedImageBuffer], { type: "image/png" }),
      `processed_${file.name}`
    );

    // Update database record
    await db
      .update(images)
      .set({
        processedImageUrl: getS3Url(processedFileKey),
        processedFileKey,
        status: "completed",
        updatedAt: new Date(),
      })
      .where(eq(images.id, imageRecord.id));

    return NextResponse.json({
      success: true,
      imageUrl: getS3Url(processedFileKey),
      originalImageUrl,
    });
  } catch (error) {
    console.error("Error processing image:", error);
    return NextResponse.json(
      { error: "Failed to process image" },
      { status: 500 }
    );
  }
}
